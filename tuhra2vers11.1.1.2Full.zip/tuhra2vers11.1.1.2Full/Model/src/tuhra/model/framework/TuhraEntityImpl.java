package tuhra.model.framework;

import oracle.jbo.server.EntityImpl;

public class TuhraEntityImpl extends EntityImpl {
}
