package tuhra.model.framework;

import oracle.jbo.server.ViewObjectImpl;

public class TuhraViewObjectImpl extends ViewObjectImpl {
}
